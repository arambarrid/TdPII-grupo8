var control_valor;
var singleValue;
var myLineChart;
var myLineChart2;
var myBarChart;
var i;
var datamqtt;
var datahttp;


$(document).ready(function(){
 

  $.get("/tiempos_sens",function(data){

    /*Se crea la tabla*/
    $("#tmqtt2").html(data.tmqtt2.toString());
    $("#tmqtt1").html(data.tmqtt1.toString());
    $("#tmqtt0").html(data.tmqtt0.toString());
    $("#thttp2").html(data.thttp2.toString());
    $("#thttp1").html(data.thttp1.toString());
    $("#thttp0").html(data.thttp0.toString());

    $("#bmqtt2").html(data.bmqtt2.toString());
    $("#bmqtt1").html(data.bmqtt1.toString());
    $("#bmqtt0").html(data.bmqtt0.toString());
    $("#bhttp2").html(data.bhttp2.toString());
    $("#bhttp1").html(data.bhttp1.toString());
    $("#bhttp0").html(data.bhttp0.toString());


    /*Se crea el grafico*/
    myLineChart = new Chart(document.getElementById("mychart"), {
    type: 'line',
    data: {
    labels: ["0", "1", "2", "3", "4"],
    datasets: [{ 
        data: [data.tmqtt4,data.tmqtt3,data.tmqtt2,data.tmqtt1,data.tmqtt0],
        label: "MQTT",
        fill: false,
        lineTension: 0.1,
        backgroundColor: "rgba(75,192,192,0.4)",
        borderColor: "rgba(75,192,192,1)",
        borderCapStyle: 'butt',
        borderDash: [],
        borderDashOffset: 0.0,
        borderJoinStyle: 'miter',
        pointBorderColor: "rgba(75,192,192,1)",
        pointBackgroundColor: "#fff",
        pointBorderWidth: 1,
        pointHoverRadius: 5,
        pointHoverBorderColor: "rgba(220,220,220,1)",
        pointHoverBorderWidth: 2,
        pointRadius: 5,
        pointHitRadius: 10,
      },  { 
        data: [data.thttp4,data.thttp3,data.thttp2,data.thttp1,data.thttp0],
        label: "HTTP",
            fill: false,
            lineTension: 0.1,
            backgroundColor: "rgba(34,3,192,1)",
            borderColor: "rgba(34,3,192,1)",
            borderCapStyle: 'butt',
            borderDash: [],
            borderDashOffset: 0.0,
            borderJoinStyle: 'miter',
            pointBorderColor: "rgba(75,192,192,1)",
            pointBackgroundColor: "#fff",
            pointBorderWidth: 1,
            pointHoverRadius: 5,
            pointHoverBorderColor: "rgba(220,220,220,1)",
            pointHoverBorderWidth: 2,
            pointRadius: 5,
            pointHitRadius: 10,
      }
    ]
  },
  options: {
    title: {
      text: 'Tiempo total de rafaga completa(s)',
      display: true,
      position: 'top',
      align: 'end'
    }

  } 
  });


    myLineChart2 = new Chart(document.getElementById("mychart2"), {
    type: 'line',
    data: {
    labels: ["0", "1", "2", "3", "4"],
    datasets: [{ 
        data: [data.bmqtt4,data.bmqtt3,data.bmqtt2,data.bmqtt1,data.bmqtt0],
        label: "MQTT",
        fill: false,
        lineTension: 0.1,
        backgroundColor: "rgba(75,192,192,0.4)",
        borderColor: "rgba(75,192,192,1)",
        borderCapStyle: 'butt',
        borderDash: [],
        borderDashOffset: 0.0,
        borderJoinStyle: 'miter',
        pointBorderColor: "rgba(75,192,192,1)",
        pointBackgroundColor: "#fff",
        pointBorderWidth: 1,
        pointHoverRadius: 5,
        pointHoverBorderColor: "rgba(220,220,220,1)",
        pointHoverBorderWidth: 2,
        pointRadius: 5,
        pointHitRadius: 10,
      },  { 
        data: [data.bhttp4,data.bhttp3,data.bhttp2,data.bhttp1,data.bhttp0],
        label: "HTTP",
            fill: false,
            lineTension: 0.1,
            backgroundColor: "rgba(34,3,192,1)",
            borderColor: "rgba(34,3,192,1)",
            borderCapStyle: 'butt',
            borderDash: [],
            borderDashOffset: 0.0,
            borderJoinStyle: 'miter',
            pointBorderColor: "rgba(75,192,192,1)",
            pointBackgroundColor: "#fff",
            pointBorderWidth: 1,
            pointHoverRadius: 5,
            pointHoverBorderColor: "rgba(220,220,220,1)",
            pointHoverBorderWidth: 2,
            pointRadius: 5,
            pointHitRadius: 10,
      }
    ]
  },
  options: {
    title: {
      display: true,
      text: 'Cantidad de bytes recibidos'
    }
  } 
  });


    /*Se crea el grafico*/
    myBarChart2 = new Chart(document.getElementById("mychart3"), {
    type: 'bar',
    data: {
      labels: ["HTTP", "MQTT"],
      datasets: [
        {
          //label: "Valores promedio (en bytes)",
          backgroundColor: ["#8e5ea2","#3e95cd"],
          data: [(data.bhttp4+data.bhttp3+data.bhttp2+data.bhttp1+data.bhttp0)/5,(data.bmqtt4+data.bmqtt3+data.bmqtt2+data.bmqtt1+data.bmqtt0)/5]
        }
      ]
    },
    options: {
        scales: {
            yAxes: [{
                display: true,
                ticks: {
                    beginAtZero: true,
                    steps: 50,
                    stepValue: 5,
                    max: 6000
                }
            }]
        },
      legend: { display: false },
      title: {
        display: true,
        text: 'Valores promedio (en bytes)'
      }
    }
  });

 
    /*Se crea el grafico*/
    myBarChart2 = new Chart(document.getElementById("mychart4"), {
    type: 'bar',
    data: {
      labels: ["HTTP", "MQTT"],
      datasets: [
        {
          //label: "Valores promedio (en bytes)",
          backgroundColor: [ "#8e5ea2","#3e95cd"],
          data: [(data.thttp4+data.thttp3+data.thttp2+data.thttp1+data.thttp0)/5,(data.tmqtt4+data.tmqtt3+data.tmqtt2+data.tmqtt1+data.tmqtt0)/5]
        }
      ]
    },
    options: {
        scales: {
            yAxes: [{
                display: true,
                ticks: {
                    beginAtZero: true,
                    steps: 10,
                    stepValue: 5,
                    max: 50
                }
            }]
        },
      legend: { display: false },
      title: {
        display: true,
        text: 'Valores de tiempo promedio (en segundos)'
      }
    }
  });

//$("#texto_estado").html("El tiempo de conexión en MQTT fue de 15 segundos y en HTTP de 30 segundos");




  });


  
});




function changeValue(value) {
          window.print("pepe")
    //$.get("/valores",function(data){
     // $("#selection").html(data.per_sens.toString());
    //});
  }

