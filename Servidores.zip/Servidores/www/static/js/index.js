var control_valor;
var control_metrica;
var singleValue;
var estado_med;

$(document).ready(function(){
  check_estado();
  estado_med=0;
  puntos=1;
  control_valor=setInterval(refresh,2000);

  //periodo_actualizacion
  $('#selection').change(function(){
        var singleValue=$(this).find("option:selected").attr('name');       
        clearInterval(control_valor);
        control_valor=setInterval(refresh,(singleValue*1000).toString());
        this.value = singleValue.toString();
  });

  //seleccion del cliente (periodo)
  $('#selection_cliente').change(function(){
        var singleValue=$(this).find("option:selected").attr('name');
        $.post('/periodo_cliente', { periodo: singleValue });
  });

  //Iniciar MQTT
  $('#inicHTTP').click(function() {
      control_metrica=setInterval(refreshmetrica,1000);
      $.post('/inicio_metrica', { "protocolo": "1" });
    });
  
    $('#inicMQTT').click(function() {
      control_metrica=setInterval(refreshmetrica,1000);
      $.post('/inicio_metrica', { "protocolo": "2" });
    });


});

function check_estado(){
    $.get("/estado_metricas",function(data){
    //si esta midiendo se hace algo. sino no se hace nada
    //alert(data.estado_medicion)
    if (data.estado_medicion==0)
      $("#texto_estado").html("Para comenzar la medición, presione Iniciar MQTT o Iniciar HTTP");
    if (data.estado_medicion==1)
      $("#texto_estado").html("Se esta realizando la operación, espere por favor...");
    
    if (data.estado_medicion==2){
      obtener_ultimametrica();    
    }
  });
}

function obtener_ultimametrica(){
      $.get("/ultima_metrica",function(data){
          $("#texto_estado").html("Valores obtenidos, se obtuvieron " + data.bytes + " bytes"
            + " y demoró " + data.tiempo + " segundos")
          clearInterval(control_metrica);

      });
    }


function refreshmetrica() {
        check_estado();
}


function refresh() {
        $.get("/valores_sens",function(data){
          if (data.luz != 0 && data.co2 != 0) {
            $("#luz").html(data.luz);
            $("#gas").html(data.co2/100);
        }

        });
}

function changeValue(value) {
          window.print("pepe")
    //$.get("/valores",function(data){
     // $("#selection").html(data.per_sens.toString());
    //});
  }

