from database import Database
from models import Tiemposmqtt
from models import Tiemposhttp
from models import Samples

import random
import time
import signal
import sys


class GracefulKiller:
    kill_now = False
    def __init__(self):
        signal.signal(signal.SIGINT, self.exit_gracefully)
        signal.signal(signal.SIGTERM, self.exit_gracefully)

    def exit_gracefully(self, signum, frame):
        self.kill_now = True

"""main: Genera los parametros requeridos y 
los almacena en la base de datos
Parametros recibidos: session de la db
"""

def main(session):
    killer = GracefulKiller()
    while(1):
        #asignacion de parametros a los valores
        r5 = Samples(co2=random.randint(20,60),luz=random.randint(20,60))
        session.add(r5)
        session.commit()

        #r6 = Samples(co2=random.randint(20,60))
        #session.add(r5)
        #session.commit()

        #r = Tiemposhttp(idtiempos=1,valor=random.randint(20,60))
        #session.add(r)
        #session.commit()
        
        #r2 = Tiemposmqtt(idtiempos=1,valor=random.randint(20,60))
        #session.add(r2)
        #session.commit()
        #r3 = Tiemposhttp(idtiempos=2,valor=random.randint(20,60))
        #session.add(r3)
        #session.commit()
        #r4 = Tiemposmqtt(idtiempos=2,valor=random.randint(20,60))
        ##session.add(r4)
        #session.commit()

        print("Valores actualizados")
        time.sleep(20)
        if killer.kill_now:
            session.close()
            break

if __name__ == '__main__':   
    db = Database()
    session = db.get_session()
    main(session)