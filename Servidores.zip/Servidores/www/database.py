from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from models import Samples
from decimal import Decimal
from models import Tiemposmqtt
from models import Tiemposhttp
from models import Tiemposconexion

import os

class Database(object):
    session = None
    db_user = os.getenv("DB_USER") if os.getenv("DB_USER") != None else "example"
    db_pass = os.getenv("DB_PASS") if os.getenv("DB_PASS") != None else "example"
    db_host = os.getenv("DB_HOST") if os.getenv("DB_HOST") != None else "db"
    db_name = os.getenv("DB_NAME") if os.getenv("DB_NAME") != None else "samples"
    db_port = os.getenv("DB_PORT") if os.getenv("DB_PORT") != None else "3306"
    Base = declarative_base()
    

    def get_session(self):
        if self.session == None:
            connection = 'mysql+mysqlconnector://%s:%s@%s:%s/%s' % (self.db_user,self.db_pass,self.db_host,self.db_port,self.db_name)
            engine = create_engine(connection,echo=True)
            connection = engine.connect()
            Session = sessionmaker(bind=engine)
            self.session = Session()
            self.Base.metadata.create_all(engine)
        return self.session
    


    """get_valores: Obtiene los valores requeridos de la db
    Retorno:
        Devuelve un arreglo con los parametros obtenidos y/o calculados
    """
    def get_valores(self):


        #Se obtiene la sesion
        session = self.get_session()

        datos = session.query(Samples).order_by(Samples.id.desc()).first()
        
        #Se cierra la sesion
        session.close()

        #Arreglo auxiliar
        parametros=[0,0]
        
        parametros[0] = datos.co2
        parametros[1] = datos.luz

        
        return parametros

    def obtenerultmetr(self,protocolo):
        session = self.get_session()
        parametros=[0,0]

        if (protocolo=="1"):
            tiempo = session.query(Tiemposhttp).filter_by(idtiempos=1).order_by(Tiemposhttp.id.desc()).first()
            bytes = session.query(Tiemposhttp).filter_by(idtiempos=2).order_by(Tiemposhttp.id.desc()).first()
            parametros[0]=tiempo.valor
            parametros[1]=bytes.valor
        elif (protocolo=="2"):
            tiempo = session.query(Tiemposmqtt).filter_by(idtiempos=1).order_by(Tiemposmqtt.id.desc()).first()
            bytes = session.query(Tiemposmqtt).filter_by(idtiempos=2).order_by(Tiemposmqtt.id.desc()).first()
            parametros[0]=tiempo.valor
            parametros[1]=bytes.valor
        
        session.close()
        return parametros

    def obtenertiempos(self):
        session = self.get_session()

        byteshttp = session.query(Tiemposhttp).filter_by(idtiempos=2).order_by(Tiemposhttp.id.desc()).limit(5).all()
        bytesmqtt = session.query(Tiemposmqtt).filter_by(idtiempos=2).order_by(Tiemposmqtt.id.desc()).limit(5).all()

        tiemposhttp = session.query(Tiemposhttp).filter_by(idtiempos=1).order_by(Tiemposhttp.id.desc()).limit(5).all()
        tiemposmqtt = session.query(Tiemposmqtt).filter_by(idtiempos=1).order_by(Tiemposmqtt.id.desc()).limit(5).all()

        #Se cierra la sesion
        session.close()

        i = 0
        #Arreglo auxiliar
        parametros=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]


        for result in tiemposmqtt:
            parametros[i] = result.valor
            i = i+1

        for result in tiemposhttp:
            parametros[i] = result.valor
            i = i+1

        for result in bytesmqtt:
            parametros[i] = result.valor
            i = i+1

        for result in byteshttp:
            parametros[i] = result.valor
            i = i+1

        


        print("longitud" + str(len(parametros)))
        for l in parametros:
            print("DATO "+ str(l))
        
        return parametros



    def put_values(self,data):

        session = self.get_session()
        r = Samples(co2=data["co2"],luz=data["luz"])
        session.add(r)
        session.commit()


    def put_tiemposconexion(self,data):

        session = self.get_session()
        #asignacion de parametros a los valores
        r = Tiemposconexion(mqtt=data["mqtt"],http=data["http"])

        #agregarlos a la sesion obtenida en el main principal
        session.add(r)
        session.commit()


    def put_tiempos(self,tiempos,bytes,id):

        session = self.get_session()
        #asignacion de parametros a los valores
        if id==1:
            r = Tiemposhttp(valor=Decimal(tiempos),idtiempos=1)
            r2 = Tiemposhttp(valor=Decimal(bytes),idtiempos=2)
        elif id==2:
            r = Tiemposmqtt(valor=Decimal(tiempos),idtiempos=1)
            r2 = Tiemposmqtt(valor=Decimal(bytes),idtiempos=2)

        #agregarlos a la sesion obtenida en el main principal
        session.add(r)
        session.add(r2)
        session.commit()

    def MQTT_put_values(self,data):
        session = self.get_session()
        z = Samples(co2=data[0],luz=data[1])
        session.add(z)
        session.commit()