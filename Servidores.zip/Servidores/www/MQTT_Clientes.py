import random
import signal
import sys
from paho.mqtt import client as mqtt
from database import Database
from time import time

db = Database()
HOST = 'mosquitto'
PORT = 1883


class MQTT_clientesub:

    tiempo_inicial=0
    tiempo_final=0
    tiempo_total=0
    tamanio_total=0
    estado=0;

    def iniciar(self):
        client = mqtt.Client(
        client_id="Suscriptor", clean_session=True)
        client.on_connect = self.on_connect 
        client.on_message = self.on_message
        client.connect(HOST, PORT, 60)
        client.loop_start()

    #Espera CONNACK del lado del server y ejecuta la funcion
    #Genera una suscripcion al topico
    def on_connect(self,client, userdata, flags, rc):
        print('Connected with result code ' + str(rc))
        client.subscribe('datos')

    #Cuando se recibe el mensaje inicia el almacenamiento
    #de los valores en la base de datos
    def on_message(self,client, userdata, msg):
        #print(msg.topic + ' ' + msg.payload.decode('utf-8'))
        print("TAMANIO " + str(self.tamanio_total))
        z=(msg.payload.decode('utf-8')).split(",")
        if z[0] == "0" and z[1] == "2":
            self.tiempo_inicial = time()
            self.tamanio_total = 0 
            self.estado=1
        elif z[0] == "2" and z[1] == "0":
            self.estado=2
            self.tiempo_final = time() 
            self.tiempo_ejecucion = self.tiempo_final - self.tiempo_inicial
            self.tamanio_total = self.tamanio_total + 12
            db.put_tiempos(self.tiempo_ejecucion,self.tamanio_total,2)

        else:
            self.tamanio_total = self.tamanio_total + 14

        #client.loop_stop()
        #client.disconnect()

    def getestado(self):
        return self.estado


class MQTT_clientepub:

    def enviar_msg(self,topico,mensaje):
        client = mqtt.Client("Publicador")
        client.connect(HOST,PORT)
        client.loop_start()
        client.publish(topico,mensaje)
        client.loop_stop()
        client.disconnect()


   
