# Imports
from aux_pro import Process
from database import Database
from flask import Flask
from flask import jsonify
from flask import render_template
from flask import request
from models import Samples
from flask import Response

from MQTT_Clientes import MQTT_clientesub
from MQTT_Clientes import MQTT_clientepub
from time import time
import sys
pro = Process()


import signal

app = Flask(__name__)
periodo_sensado=10
mqttsub=MQTT_clientesub()


#mqttpub = MQTT_clientepub()
#0 no esta midiendo, 1 esta midiendo
estado_medicion=0

#1 se indica a arduino que comience a sensar
protocolo_medicion_arduino=0

#1 http, 2 mqtt
protocolo_medicion=0

#tiempos para obtencion de metricas
tiempo_inicial=0
tiempo_final=0
tiempo_total=0

#contador de tamanio
tamanio_total=0

#tamanio paquetes http
tamanio_httpdata=0
#contador de paquetes http
cont_httpdata=0

db = Database()
r=0

# Define la ruta para ingresar en el navegador
@app.route('/')
def index():
	global r
	global estado_medicion
	if(estado_medicion!=1):
		estado_medicion=0
	if(mqttsub.getestado()==2):
		estado_medicion=0
	#parametros=db.obtenerultmetr(1)
	#parametros=db.obtenerultmetr(1)
	#if pro.is_running():
	#	pro.start_process()
	if(r==0):
		mqttsub.iniciar()
		r=1
	return render_template('index.html')


@app.route('/obtencion')
def obtencion():
    return render_template('obtencion.html')

#EL cliente indica que se quiere comenzar a medir
@app.route('/inicio_metrica', methods = ["POST"])
def inicio_metrica():
	global estado_medicion
	global protocolo_medicion
	global protocolo_medicion_arduino

	data = request.form
	if(estado_medicion!=1):
		protocolo_medicion=data["protocolo"]
		protocolo_medicion_arduino=data["protocolo"]
	estado_medicion=1
	return render_template('index.html')



#Estado de las metricas. Esta o no midiendo?
@app.route('/estado_metricas', methods = ["GET"])
def estado_metricas():
	global estado_medicion
	global protocolo_medicion
	global mqttsub
	#si el protocolo es mqtt
	if(protocolo_medicion=="2"):
		if(mqttsub.getestado()==2):
			estado_medicion=2
	return jsonify({"estado_medicion":estado_medicion})


#Se obtiene la ultima metrica obtenida
@app.route('/ultima_metrica', methods = ["GET"])
def ultima_metrica():
	global protocolo_medicion
	parametros=db.obtenerultmetr(protocolo_medicion)
	#Se vuelve a setear el estado de medicion en 0
	estado_medicion=0
	return jsonify({"tiempo":parametros[0],"bytes":parametros[1]})



#Obtencion de valores de tiempos para actualizar la pagina web
@app.route('/tiempos_sens', methods = ["GET"])
def tiempos_sens():
	arr = db.obtenertiempos()
	return jsonify({"tmqtt0":arr[0],"tmqtt1":arr[1],"tmqtt2":arr[2],"tmqtt3":arr[3],"tmqtt4":arr[4],"thttp0":arr[5],"thttp1":arr[6],"thttp2":arr[7],"thttp3":arr[8],"thttp4":arr[9],"bmqtt0":arr[10],"bmqtt1":arr[11],"bmqtt2":arr[12],"bmqtt3":arr[13],"bmqtt4":arr[14],"bhttp0":arr[15],"bhttp1":arr[16],"bhttp2":arr[17],"bhttp3":arr[18],"bhttp4":arr[19]}) 
 


#Obtencion de valores de sensado para actualizar la pagina web
@app.route('/valores_sens', methods = ["GET"])
def valores_sens():
	try:
		datos = db.get_valores()
	except:
		datos=[0,0]
		datos[0]=0
		datos[1]=0
		pass
	return jsonify({"co2":datos[0],"luz":datos[1]})

#Obtencion de valor de periodo de sensado desde la pagina web
@app.route('/periodo_cliente', methods = ["POST"])
def periodo_cliente():
	global periodo_sensado
	data = request.form
	periodo_sensado=data["periodo"]
	#mqttpub.enviar_msg("periodo",periodo_sensado)
	return render_template('index.html')

#el cliente solicita periodo_sensado, y si se desea comenzar medidas
@app.route('/parametros_cliente', methods = ["GET"])
def parametros_cliente():
	global periodo_sensado
	global protocolo_medicion
	global protocolo_medicion_arduino

	#Se indico desde la pagina web que se quiere obtener metricas
	if(protocolo_medicion!=0):
		if(protocolo_medicion_arduino!=0):
			protocolo_medicion_arduino=0
			return jsonify({"protocolo_medicion":protocolo_medicion,"periodo_sensado":periodo_sensado}) 
		else:
			return jsonify({"protocolo_medicion":0,"periodo_sensado":periodo_sensado}) 
	else:
		return jsonify({"protocolo_medicion":0,"periodo_sensado":periodo_sensado}) 



#Obtencion de valores para actualizar parametros
@app.route('/valores', methods = ["GET"])
def get_valores():
	global periodo_sensado
	#r = Response(response=str(periodo_sensado), status=200, mimetype="application/xml")
	#r.headers["Content-Type"] = "text/xml; charset=utf-8"
	#return r
	return jsonify({"per_sens":periodo_sensado}) 

#El cliente (Arduino) envia la informacion al servidor
@app.route('/insertar_valores', methods = ["POST"])
def insertar_valores():
	d_m={}
	data=request.form
	d_m["co2"] = data["co2"]
	d_m["luz"] = data["luz"]
	db.put_values(d_m)
	return render_template('responsepost.html')


#El cliente (Arduino) envia el tiempo de conexion
@app.route('/tcon', methods = ["POST"])
def tcon():
	data=request.form
	d_m={}
	#tiempo de conexion http
	d_m["http"] = data["co2"]
	#tiempo de conexion mqtt
	d_m["mqtt"] = data["luz"]
	b.put_tiemposconexion(d_m)
	return render_template('responsepost.html')


#Indica al server que debe insertar valores a la base de datos
@app.route('/insertar', methods = ["POST"])
def insertar():
	global tiempo_inicial
	global tiempo_final
	global tiempo_ejecucion
	global estado_medicion
	global tamanio_httpdata
	global cont_httpdata
	data = request.form

	#inicio de recepcion de metrica
	if data["co2"] == "0" and data["luz"] == "1":
		tiempo_inicial = time() 
	#fin de recepcion de metrica
	elif data["co2"] == "1" and data["luz"] == "0":
		tiempo_final = time() 
		tiempo_ejecucion = tiempo_final - tiempo_inicial
		cont_httpdata = cont_httpdata +1
		tamanio_httpdata = 226*(cont_httpdata-1)+223
		db.put_tiempos(tiempo_ejecucion,tamanio_httpdata,1)
		tamanio_httpdata=0
		cont_httpdata=0
		estado_medicion=2;
	#otros datos
	else:
		cont_httpdata = cont_httpdata +1
	return render_template('responsepost.html')




#El cliente (web+javascript) solicita un cambio en el periodo de sensado
@app.route('/param_server', methods = ["POST"])
def almacenar_per_sensado():
    data = request.form
    self.periodo_sensado = data["periodo_sensado"]


if __name__ == "__main__":
    # Define HOST and port
    app.run(host='0.0.0.0', port=8888)





