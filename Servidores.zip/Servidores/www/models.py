import datetime

from sqlalchemy.schema import Column
from sqlalchemy.types import Integer
from sqlalchemy.types import Float
from sqlalchemy.ext.declarative import declarative_base

#Base declarativa para declarar modelos
Base = declarative_base()


#Creacion de un modelo
class Samples(Base):
    __tablename__ = 'samples'
    id=Column(Integer, primary_key=True)
    co2=Column('co2', Integer)
    luz=Column('luz', Integer)

#Creacion de un modelo
class Tiemposmqtt(Base):
    __tablename__ = 'tiemposmqtt'
    id=Column(Integer, primary_key=True)
    idtiempos=Column('idtiempos',Integer)
    valor=Column('valor', Integer)

#Creacion de un modelo
class Tiemposhttp(Base):
    __tablename__ = 'tiemposhttp'
    id=Column(Integer, primary_key=True)
    idtiempos=Column('idtiempos',Integer)
    valor=Column('valor', Integer)

#Creacion de un modelo
class Tiemposconexion(Base):
    __tablename__ = 'tiemposconexion'
    id=Column(Integer, primary_key=True)
    http=Column('http',Integer)
    mqtt=Column('mqtt', Integer)

