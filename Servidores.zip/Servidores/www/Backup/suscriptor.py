import random
import time
import signal
import sys
from paho.mqtt import client as mqtt
from database import Database

db = Database()
HOST = 'mosquitto'
PORT = 1883

class MQTT_clientesub:

    #Espera CONNACK del lado del server y ejecuta la funcion
    #Genera una suscripcion al topico
    def on_connect(client, userdata, flags, rc):
        print('Connected with result code ' + str(rc))
        client.subscribe('/topic1')
        client.loop_start()

    #Cuando se recibe el mensaje inicia el almacenamiento
    #de los valores en la base de datos
    def on_message(client, userdata, msg):
        print(msg.topic + ' ' + msg.payload.decode('utf-8'))
        db.MQTT_put_values("pepe")
        client.loop_stop()


    client = mqtt.Client(
    client_id="ELpepo", clean_session=True)
    client.on_connect = on_connect 
    client.on_message = on_message
    client.connect(HOST, PORT, 20)
    client.loop_forever()
    